@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Tablero inicial</h1>
@stop

@section('content')
<!-- aquí va contenido -->
@endsection
